"use client";

import { useMemo, useState } from "react";
import { monthlyIncomeTax } from "@/lib/incomeTax";
import { topPercentOf, incomePercentileMeta } from "@/lib/incomePercentile";
import salaryData from "@/data/salary-compare.json";
import AdSlot from "@/components/AdSlot";
import Link from "next/link";

const won = (n: number) => Math.round(n).toLocaleString("ko-KR") + "원";
const manwon = (n: number) => Math.round(n / 10000).toLocaleString("ko-KR") + "만";

// 2026 근로자 본인부담 요율
const PENSION_RATE = 0.045;
const PENSION_BASE_MAX = 6590000; // 국민연금 기준소득월액 상한
const HEALTH_RATE = 0.03595;
const LTC_RATE_OF_HEALTH = 0.1314;
const EMPLOYMENT_RATE = 0.009;

// 종합소득세 과세표준 구간 (참고 표시용)
const TAX_BRACKETS = [
  { upTo: "1,400만", rate: "6%" },
  { upTo: "5,000만", rate: "15%" },
  { upTo: "8,800만", rate: "24%" },
  { upTo: "1억 5천만", rate: "35%" },
  { upTo: "3억", rate: "38%" },
  { upTo: "3억 초과", rate: "40%~45%" },
];

function calcNet(annualGross: number, dependents: number) {
  const monthlyGross = annualGross / 12;
  const pension = Math.min(monthlyGross, PENSION_BASE_MAX) * PENSION_RATE;
  const health = monthlyGross * HEALTH_RATE;
  const ltc = health * LTC_RATE_OF_HEALTH;
  const employment = monthlyGross * EMPLOYMENT_RATE;
  const incomeTax = monthlyIncomeTax(monthlyGross, pension, dependents);
  const localTax = Math.floor(incomeTax * 0.1);
  const totalDeduction = pension + health + ltc + employment + incomeTax + localTax;
  const net = monthlyGross - totalDeduction;
  return {
    monthlyGross,
    deductions: [
      { label: "국민연금 (4.5%)", value: pension },
      { label: "건강보험 (3.595%)", value: health },
      { label: "장기요양보험", value: ltc },
      { label: "고용보험 (0.9%)", value: employment },
      { label: "소득세", value: incomeTax },
      { label: "지방소득세", value: localTax },
    ],
    totalDeduction,
    net,
    annualNet: net * 12,
    netRate: net / monthlyGross,
  };
}

// 비교 막대그래프용 기준 연봉들 (만원)
const COMPARE = [3000, 5000, 7000, 9000, 10000, 12000, 15000];

export default function WorkerNetCalc() {
  const [annualManwon, setAnnualManwon] = useState(5000);
  const [dependents, setDependents] = useState(0);

  const my = useMemo(() => calcNet(annualManwon * 10000, dependents), [annualManwon, dependents]);

  const topPct = useMemo(() => topPercentOf(annualManwon * 10000), [annualManwon]);
  const vsMedian = (annualManwon * 10000) / incomePercentileMeta.median;

  // 대기업 평균연봉과 비교 (가까운 순으로 3개, 이미 있는 DART 데이터 재사용)
  const nearbyCompanies = useMemo(() => {
    const myIncome = annualManwon * 10000;
    return salaryData.companies
      .slice()
      .sort((a, b) => Math.abs(a.avgSalary - myIncome) - Math.abs(b.avgSalary - myIncome))
      .slice(0, 3)
      .sort((a, b) => b.avgSalary - a.avgSalary);
  }, [annualManwon]);

  const bars = useMemo(() => {
    const list = COMPARE.includes(annualManwon) ? COMPARE : [...COMPARE, annualManwon].sort((a, b) => a - b);
    const max = Math.max(...list) * 10000;
    return list.map((m) => {
      const r = calcNet(m * 10000, dependents);
      return {
        annual: m,
        gross: m * 10000,
        net: r.annualNet,
        netW: (r.annualNet / max) * 100,
        taxW: ((m * 10000 - r.annualNet) / max) * 100,
        rate: r.netRate,
        mine: m === annualManwon,
      };
    });
  }, [annualManwon, dependents]);

  return (
    <div className="mx-auto max-w-[1280px] px-4">
      {/* 광고 (입력칸 위, 전체 폭) */}
      <AdSlot id="calc-worker-net-mid" />

      <div className="grid gap-6 lg:grid-cols-[380px_1fr] lg:items-start">
        {/* ═══ 왼쪽: 입력 ═══ */}
        <div className="space-y-4">
          <div className="space-y-4 rounded-xl border border-[rgba(46,68,148,0.14)] bg-[rgba(46,68,148,0.03)] p-5">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-[#2E4494]">기본 입력</p>
              <p className="mt-0.5 text-base font-bold text-[#1B2A4A]">연봉과 부양가족</p>
            </div>

            <label className="block">
              <span className="text-sm font-medium text-[#5B6478]">연봉 (만원)</span>
              <div className="mt-1.5">
                <input
                  type="text"
                  inputMode="numeric"
                  value={annualManwon === 0 ? "" : annualManwon.toLocaleString("ko-KR")}
                  onChange={(e) => setAnnualManwon(Number(e.target.value.replace(/[^0-9]/g, "")) || 0)}
                  className="w-full rounded-lg border border-[rgba(46,68,148,0.22)] bg-white px-3 py-3 text-right text-base tabular-nums"
                />
              </div>
              <span className="mt-1 block text-xs font-normal text-[#8B93A6]">
                세전 계약 연봉. 5천만 원이면 5000
              </span>
            </label>

            <label className="block">
              <span className="text-sm font-medium text-[#5B6478]">부양가족 수</span>
              <div className="mt-1.5">
                <input
                  type="number"
                  min={0}
                  max={10}
                  value={dependents === 0 ? "" : dependents}
                  onChange={(e) => setDependents(Number(e.target.value) || 0)}
                  className="w-full rounded-lg border border-[rgba(46,68,148,0.22)] bg-white px-3 py-3 text-right text-base tabular-nums"
                />
              </div>
              <span className="mt-1 block text-xs font-normal text-[#8B93A6]">
                본인 제외. 소득세 인적공제 반영
              </span>
            </label>
          </div>
        </div>

        {/* ═══ 오른쪽: 결과 (sticky) ═══ */}
        <div className="space-y-5 lg:sticky lg:top-20">
          {/* 결과 요약 */}
          <div className="overflow-hidden rounded-xl border border-[rgba(46,68,148,0.14)]">
            <div className="bg-[#2E4494] px-5 py-4 text-white">
              <p className="text-sm opacity-80">월 실수령액</p>
              <p className="text-3xl font-bold tabular-nums">{won(my.net)}</p>
              <p className="mt-1 text-sm opacity-90">
                연 실수령 {won(my.annualNet)} · 세전의 {(my.netRate * 100).toFixed(1)}%
              </p>
            </div>
            <dl className="divide-y divide-[rgba(46,68,148,0.10)] bg-white text-sm">
              <Row label="월 세전 급여" value={won(my.monthlyGross)} />
              {my.deductions.map((d) => (
                <Row key={d.label} label={d.label} value={"- " + won(d.value)} muted />
              ))}
              <Row label="공제 합계" value={"- " + won(my.totalDeduction)} bold />
            </dl>
          </div>

          {/* 핵심 지표 */}
          <div className="rounded-xl border border-[rgba(46,68,148,0.14)] bg-[rgba(46,68,148,0.06)] p-5">
            <p className="text-xs font-semibold uppercase tracking-wide text-[#2E4494]">핵심 지표</p>
            <p className="mt-1 text-lg font-bold text-[#1B2A4A]">
              내 연봉은 근로소득자 상위 {topPct <= 1 ? "1% 이내" : `${topPct.toFixed(1)}%`}
            </p>
            <p className="mt-1 text-sm leading-relaxed text-[#5B6478]">
              {incomePercentileMeta.year}년 귀속 근로소득자 중위 연봉은{" "}
              <strong className="tabular-nums">{won(incomePercentileMeta.median)}</strong>입니다. 입력한 연봉은
              중위의 <strong className="tabular-nums">{vsMedian.toFixed(1)}배</strong>입니다.
            </p>
            <Link
              href="/calc/income-rank"
              className="mt-2 inline-block text-xs font-medium text-[#2E4494] underline underline-offset-2"
            >
              연봉순위 계산기에서 자세히 보기 →
            </Link>
            <p className="mt-2 text-xs text-[#8B93A6]">{incomePercentileMeta.source}</p>
          </div>

          {/* 대기업 평균연봉과 비교 */}
          <div className="rounded-xl border border-[rgba(46,68,148,0.14)] bg-white p-5">
            <p className="font-semibold text-[#1B2A4A]">대기업 평균연봉과 비교</p>
            <div className="mt-3 space-y-2">
              {nearbyCompanies.map((c) => (
                <div key={c.corpCode} className="flex items-center justify-between text-sm">
                  <span className="text-[#5B6478]">{c.name}</span>
                  <span className="tabular-nums font-medium text-[#1B2A4A]">{manwon(c.avgSalary)}만</span>
                </div>
              ))}
            </div>
            <Link
              href="/calc/salary-compare"
              className="mt-2 inline-block text-xs font-medium text-[#2E4494] underline underline-offset-2"
            >
              23개 대기업 전체 비교 보기 →
            </Link>
            <p className="mt-2 text-xs text-[#8B93A6]">{salaryData.source} 기준 전 직원 평균</p>
          </div>

          {/* 연봉별 실수령 비교 막대그래프 */}
          <div className="rounded-xl border border-[rgba(46,68,148,0.14)] bg-white p-5">
            <p className="font-semibold text-[#1B2A4A]">
              연봉별 실수령액 비교{" "}
              <span className="text-xs font-normal text-[#8B93A6]">(연간, 파란색=실수령 / 회색=세금·보험)</span>
            </p>
            <div className="mt-4 space-y-2.5">
              {bars.map((b) => (
                <div key={b.annual}>
                  <div className="mb-0.5 flex justify-between text-xs">
                    <span className={b.mine ? "font-bold text-[#2E4494]" : "text-[#7A8296]"}>
                      {b.annual.toLocaleString()}만 {b.mine && "← 내 연봉"}
                    </span>
                    <span className="tabular-nums text-[#7A8296]">
                      실수령 {manwon(b.net)} ({(b.rate * 100).toFixed(0)}%)
                    </span>
                  </div>
                  <div className="flex h-4 w-full overflow-hidden rounded bg-slate-100">
                    <div className={b.mine ? "bg-[#2E4494]" : "bg-[#2E4494]/60"} style={{ width: `${b.netW}%` }} />
                    <div className="bg-slate-300" style={{ width: `${b.taxW}%` }} />
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-3 text-xs leading-relaxed text-[#8B93A6]">
              연봉이 오를수록 높은 세율 구간에 걸리는 금액이 늘어나 실수령 비율(%)이 점점 낮아집니다. 연봉 3천만
              원은 약 90%를 받지만 1억 원은 약 80% 수준만 손에 들어오는 이유입니다.
            </p>
          </div>

          {/* 과세표준 구간 */}
          <div className="rounded-xl border border-[rgba(46,68,148,0.14)] bg-white p-5 text-sm">
            <p className="mb-3 font-semibold text-[#1B2A4A]">소득세 과세표준 구간 (누진세율)</p>
            <dl className="space-y-1.5 text-[#5B6478]">
              {TAX_BRACKETS.map((t) => (
                <div key={t.upTo} className="flex justify-between">
                  <dt>~ {t.upTo} 원</dt>
                  <dd className="font-medium tabular-nums text-[#1B2A4A]">{t.rate}</dd>
                </div>
              ))}
            </dl>
            <p className="mt-3 text-xs leading-relaxed text-[#8B93A6]">
              누진 구조라 구간을 넘는 금액에만 높은 세율이 적용됩니다. 과세표준은 연봉에서 근로소득공제·인적공제
              등을 뺀 금액이라 연봉 자체와는 다릅니다.
            </p>
          </div>
        </div>
      </div>

      {/* 판단 보조 */}
      <div className="mt-6 space-y-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-[#2E4494]">판단 보조</p>
          <p className="mt-0.5 text-base font-bold text-[#1B2A4A]">이런 상황이면 이렇게 보세요</p>
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          {WORKER_DECISION_CARDS.map((card) => (
            <div key={card.tag} className="rounded-xl border border-[rgba(46,68,148,0.14)] bg-white p-4">
              <span className="inline-block rounded-full bg-[rgba(46,68,148,0.08)] px-2 py-0.5 text-[10px] font-semibold text-[#2E4494]">
                {card.tag}
              </span>
              <p className="mt-2 text-sm font-bold text-[#1B2A4A]">{card.title}</p>
              <ul className="mt-2 space-y-1 text-xs leading-relaxed text-[#5B6478]">
                {card.bullets.map((b) => (
                  <li key={b}>· {b}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* ═══ 하단 전체 폭 (grid 밖으로 분리 — sticky 오른쪽 컬럼과 겹치는 문제 방지) ═══ */}
      <p className="mt-6 text-xs leading-relaxed text-[#8B93A6]">
        ※ 참고용 추정치입니다. 소득세는 간이세액표 산출 방식(연환산) 근사이며, 비과세 식대, 연말정산 공제 항목,
        회사별 공제 차이에 따라 실제 급여명세서와 다를 수 있습니다.
      </p>
    </div>
  );
}

const WORKER_DECISION_CARDS = [
  {
    tag: "이직 협상",
    title: "이직 제안을 받아 연봉을 비교 중이다",
    bullets: [
      "세전 연봉만 비교하면 실제 인상 체감을 놓칩니다",
      "연봉이 오를수록 높은 세율 구간이 늘어 실수령 인상폭은 항상 더 작습니다",
      "두 회사 연봉을 각각 넣어 월 실수령액 차이로 비교하세요",
    ],
  },
  {
    tag: "프리랜서 전환",
    title: "프리랜서·사업소득 전환을 고민 중이다",
    bullets: [
      "4대보험을 회사와 반씩 내던 구조에서 전액 본인 부담으로 바뀝니다",
      "매년 5월 종합소득세 신고가 필요해 원천징수 구조와 다릅니다",
      "단순 실수령액 비교보다 세후 순수입 기준으로 다시 계산해야 합니다",
    ],
  },
  {
    tag: "연말정산",
    title: "부양가족·소득공제를 최적화하고 싶다",
    bullets: [
      "부양가족 수를 바꿔가며 매월 원천징수 소득세 변화를 확인해보세요",
      "월 실수령액과 연말정산 환급액은 별개로, 원천징수를 적게 하면 환급이 늘 수 있습니다",
      "정확한 공제 항목은 국세청 홈택스 연말정산 미리보기에서 확인하세요",
    ],
  },
];

function Row({
  label,
  value,
  bold,
  muted,
}: {
  label: string;
  value: string;
  bold?: boolean;
  muted?: boolean;
}) {
  return (
    <div className="flex items-center justify-between px-5 py-2.5">
      <dt className={muted ? "text-[#7A8296]" : "font-medium text-[#1B2A4A]"}>{label}</dt>
      <dd className={`tabular-nums ${bold ? "font-bold text-[#1B2A4A]" : muted ? "text-[#7A8296]" : "text-[#1B2A4A]"}`}>
        {value}
      </dd>
    </div>
  );
}
